def snap_shot_scenario_generator():
    pass


def random_scenario_generator():
    pass
